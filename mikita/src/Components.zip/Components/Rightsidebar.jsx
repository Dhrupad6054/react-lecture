import React from 'react'

function Rightsidebar() {
    return(
        <div>Rightsidebar</div>
    )
}
export default Rightsidebar